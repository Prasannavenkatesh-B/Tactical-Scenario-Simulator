"""Core component tests."""
